class Util {
  static String enumToString(Object e) => e.toString().split('.').last;
}
