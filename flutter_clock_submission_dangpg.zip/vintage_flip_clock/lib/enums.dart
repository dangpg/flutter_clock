enum CardPosition { top, bottom }
enum AnimationDirection { visibleToHide, hideToVisible, none }
enum HourMode { AM, PM }
enum Weekday { MON, TUE, WED, THU, FRI, SAT, SUN }
